package com.dooleen.service.app.file.dao;
import com.dooleen.common.core.entity.SendLog;
import com.dooleen.common.core.tkMapper.TkMapper;

public interface ISendLogDao extends TkMapper<SendLog>{
	
}