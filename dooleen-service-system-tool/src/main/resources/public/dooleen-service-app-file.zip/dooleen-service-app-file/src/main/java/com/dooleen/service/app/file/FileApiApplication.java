package com.dooleen.service.app.file;

import javax.servlet.MultipartConfigElement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@EnableHystrix
@EnableHystrixDashboard
@Configuration
@ComponentScan(basePackages = { "com.dooleen.common.http.config", "com.dooleen.service.app.file.*",
		"com.dooleen.common.core.redis.config", "com.dooleen.common.rule.*" })
@MapperScan(basePackages = { "com.dooleen.service.app.file.dao" })
public class FileApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileApiApplication.class, args);
	}

	/**
	 * �ļ��ϴ�����
	 * 
	 * @return
	 */
	@Bean
	public MultipartConfigElement multipartConfigElement() {
		MultipartConfigFactory factory = new MultipartConfigFactory();
		// �����ļ����
		factory.setMaxFileSize("5MB"); // KB,MB
		/// �������ϴ������ܴ�С
		factory.setMaxRequestSize("5MB");
		return factory.createMultipartConfig();
	}
}
