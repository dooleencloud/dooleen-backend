package com.dooleen.service.app.file.service;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.dooleen.common.core.common.entity.CommonMsg;
import com.dooleen.common.core.constant.MqQueueConstant;
import com.dooleen.common.core.entity.FileData;
import com.dooleen.common.core.entity.vo.FileDataRequest;
import com.dooleen.common.core.msg.EmailMq;
import com.dooleen.common.core.msg.email.EmailMsg;
import com.dooleen.service.app.file.dao.FileDataDao;

@Service
public class SendEmailService {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
//	@Autowired
//	private ISendLogDao sendLogDao;
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	@Autowired
	private FileDataDao fileDataDao;

//	@Autowired
//	private GenerateNo genNo;
	
	public String unlockFileToSendEmail(
			JavaMailSender javaMailSender, CommonMsg<FileDataRequest, FileDataRequest> commonMsg) {
		
		//当前日期
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date now = new Date();
		String nowStr = sdf.format(now);
		
		FileDataRequest fileDataRequest = commonMsg.getBody().getSingleBody();
		String fileName = fileDataRequest.getFileName();
		String fileDataUrl = fileDataRequest.getFileDataUrl();
		
		//资料编号
		String fileDataNo = fileDataRequest.getFileDataNo();
		if(StringUtils.isNotBlank(fileDataNo)) {
			//查询资料信息
			FileData fileData = fileDataDao.selectByPrimaryKey(fileDataNo);
			fileDataUrl = fileData.getFileDataUrl();
			fileName = fileData.getFileName();
		}
		
		
		List<String> attachments = new ArrayList<String>();
		attachments.add(fileDataUrl);
		
		List<EmailMsg> emailMsgList = new ArrayList<EmailMsg>();
		List<String> receiverUserIds = new ArrayList<>();
		EmailMsg emailMsg = new EmailMsg();
		receiverUserIds.add(fileDataRequest.getEmail());
		emailMsg.setReceiverEmailAddrs(receiverUserIds);
		
		StringBuffer emailContent = new StringBuffer();
		emailContent.append("亲，详见附件！");
		emailMsg.setEmailContent(emailContent.toString());
		emailMsg.setEmailSubject("练习GO资料_" + fileName);
		emailMsg.setAttachments(attachments);
		emailMsgList.add(emailMsg);
		
		EmailMq emailMq = new EmailMq();
		emailMq.setEmailMsgList(emailMsgList);
		emailMq.setUserId(fileDataRequest.getUserId());
		emailMq.setCreateDatetime(nowStr);
		
		rabbitTemplate.convertAndSend(MqQueueConstant.EMAIL_COMMON_QUEUE, emailMq);
		logger.info("发送邮件写入消息到mq成功！！！");
		return "success!";
	}

	public byte[] unlockFileToPreview(String fileDataNo) {
		
		//查询资料文件信息
		FileData fileData = fileDataDao.selectByPrimaryKey(fileDataNo);
		if(null == fileData || StringUtils.isBlank(fileData.getFileDataUrl())) {
			return null;
		}

        byte[] data = null;
 
        try {
            FileInputStream fis = new FileInputStream(fileData.getFileDataUrl());
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
 
            int len;
            byte[] buffer = new byte[1024];
            while ((len = fis.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }
 
            data = baos.toByteArray();
 
            fis.close();
            baos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
	}
}
