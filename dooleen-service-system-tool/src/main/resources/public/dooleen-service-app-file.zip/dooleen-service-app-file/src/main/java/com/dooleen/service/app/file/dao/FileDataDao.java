package com.dooleen.service.app.file.dao;

import com.dooleen.common.core.entity.FileData;
import com.dooleen.common.core.tkMapper.TkMapper;

public interface FileDataDao extends TkMapper<FileData> {

}
