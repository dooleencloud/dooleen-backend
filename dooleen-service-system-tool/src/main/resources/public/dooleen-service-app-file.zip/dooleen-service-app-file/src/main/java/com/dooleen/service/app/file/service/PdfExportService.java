package com.dooleen.service.app.file.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dooleen.common.core.common.entity.CommonMsg;
import com.dooleen.common.core.common.entity.NullEntity;
import com.dooleen.common.core.entity.QuestionSheet;
import com.dooleen.common.core.entity.SendLog;
import com.dooleen.common.core.entity.StudentInfo;
import com.dooleen.common.core.entity.TitleDetail;
import com.dooleen.common.core.utils.EntityInitUtils;
import com.dooleen.common.core.utils.GenerateNo;
import com.dooleen.service.app.file.dao.ISendLogDao;
import com.dooleen.service.app.file.dao.IStudentInfoDao;
import com.dooleen.service.app.file.dao.QuestionSheetDao;
import com.dooleen.service.app.file.dao.TitleDetailDao;
import com.dooleen.service.app.file.entity.ExportDomain;
import com.dooleen.service.app.file.entity.SendEmailPdf;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.itextpdf.tool.xml.html.CssAppliers;
import com.itextpdf.tool.xml.html.CssAppliersImpl;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.parser.XMLParser;
import com.itextpdf.tool.xml.pipeline.css.CSSResolver;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.AbstractImageProvider;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;

import freemarker.template.Configuration;
import freemarker.template.Template;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
import sun.misc.BASE64Encoder;

/**
 * Copy Right Information : 独领 <br>
 * Project : 神口算 <br>
 * Description : <br>
 * Author :李秋宏 <br>
 * Maintainer: <br>
 * Version : <br>
 * Since : <br>
 * Date :2019-04-21 <br>
 * Update: <br>
 */
@Service
public class PdfExportService {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private QuestionSheetDao questionSheetDao;

	@Autowired
	private TitleDetailDao titleDetailDao;

	@Autowired
	private IStudentInfoDao studentInfoDao;

	@Autowired
	private ISendLogDao sendLogDao;

	@Autowired
	private GenerateNo genNo;

	// 输出并发邮件
	public String sendMailExamPdf(JavaMailSender javaMailSender, CommonMsg<SendEmailPdf, NullEntity> commonMsg)
			throws Exception {
		SendEmailPdf sendEmailPdf = commonMsg.getBody().getSingleBody();
		String questionNo = sendEmailPdf.getQuestionNo().trim();
		byte[] bytes = getPdfStream("test.html", buildParam(questionNo));
		
		FileOutputStream fos = new FileOutputStream("/root/pdf/" + questionNo + ".pdf");
		fos.write(bytes);
		fos.close();
		
		byte[] bytes2 = getPdfStream("answer.html", buildParamAnswer(questionNo));
		FileOutputStream fos2 = new FileOutputStream("/root/pdf/答案-" + questionNo + ".pdf");
		fos2.write(bytes2);
		fos2.close();
		
		String[] fileArray = { "/root/pdf/" + questionNo + ".pdf", "/root/pdf/答案-" + questionNo + ".pdf"};
		MimeMessage message = javaMailSender.createMimeMessage();
		String status = "0";
		// MimeMessage message = jms.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom("service@dooleen.com");
			helper.setTo(sendEmailPdf.getEmail().trim());
			helper.setSubject(sendEmailPdf.getSendTitle());
			helper.setText("亲，详见附件！");
			// 验证文件数据是否为空
			if (null != fileArray) {
				FileSystemResource file = null;
				for (int i = 0; i < fileArray.length; i++) {
					// 添加附件
					file = new FileSystemResource(fileArray[i]);
					helper.addAttachment(fileArray[i].substring(fileArray[i].lastIndexOf(File.separator) + 1), file);
				}
			}
			javaMailSender.send(message); 
			log.info(">>>>>>带附件的邮件发送成功");
			status = "1";
		} catch (Exception e) {
			e.printStackTrace();
			log.info(">>>>>>发送带附件的邮件失败");
			status = "0";
		}
		// 写发送日志
		SendLog sendLog = new SendLog();
		sendLog.setLogNo(genNo.getUniversalNo());
		sendLog.setSendUserId(sendEmailPdf.getUserId());
		sendLog.setSendType("1");
		sendLog.setSendEmail("service@dooleen.com");
		sendLog.setReceiveEmail(sendEmailPdf.getEmail().trim());
		sendLog.setMessageTitle(sendEmailPdf.getSendTitle());
		sendLog.setStatus(status);
		sendLog.setContent(new JSONObject().toJSONString(sendEmailPdf));
		sendLog = EntityInitUtils.initEntityPublicInfoForInsert(sendLog, sendLog.getSendUserId());
		int sendLogIndx = sendLogDao.insertSelective(EntityInitUtils.initEntityEmptyToNull(sendLog));
		if (sendLogIndx < 1) {
			log.info(">>>>>>写发送日志错误！！！");
		} else {
			log.info(">>>>>>成功写发送日志！！");
		}
		return status;
	}

	// 输出PDF流
	public byte[] genExamPdf(String questionNo) throws Exception {
		byte[] bytes = getPdfStream("test.html", buildParam(questionNo));
		//byte[] bytes2 = getPdfStream("answer.html", buildParamAnswer(questionNo));
		return bytes;
	}
	 
	public static byte[] getPdfStream(String templateName, Map<String, Object> data) throws Exception {

		String html = getHtmlContract(templateName, data);
		// 转换成pdf流
		byte[] bytes = convertToPDF(html);
		return bytes;
	}

	/**
	 * @description PDF文件生成
	 */
	private static byte[] convertToPDF(String htmlString) throws Exception {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		// 设置文档大小
		Document document = new Document(PageSize.A4);
		PdfWriter writer = PdfWriter.getInstance(document, out);
		// itext图片立即合成
		writer.setStrictImageSequence(true);

		// 输出为PDF文件
		document.open();
		MyFontsProvider fontProvider = new MyFontsProvider();
		fontProvider.addFontSubstitute("lowagie", "garamond");
		fontProvider.setUseUnicode(true);
		CssAppliers cssAppliers = new CssAppliersImpl(fontProvider);

		CSSResolver cssResolver = XMLWorkerHelper.getInstance().getDefaultCssResolver(true);

		// HTML
		HtmlPipelineContext htmlContext = new HtmlPipelineContext(cssAppliers);
		htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());
		htmlContext.setImageProvider(new AbstractImageProvider() {
			@Override
			public Image retrieve(String src) {
				int pos = src.indexOf("base64,");
				try {
					if (src.startsWith("data") && pos > 0) {
						byte[] img = Base64.decode(src.substring(pos + 7));
						return Image.getInstance(img);
					} else if (src.startsWith("http")) {
						return Image.getInstance(src);
					}
				} catch (BadElementException ex) {
					return null;
				} catch (IOException ex) {
					return null;
				}
				return null;
			}

			@Override
			public String getImageRootPath() {
				return null;
			}
		});

		// Pipelines
		PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
		HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
		CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

		// XML Worker
		XMLWorker worker = new XMLWorker(css, true);
		XMLParser p = new XMLParser(worker);
		p.parse(new StringReader(htmlString));
		document.close();
		return out.toByteArray();
	}

	public static String getHtmlContract(String html, Map<String, Object> dataModel) throws Exception {
		Writer out = null;
		StringReader reader = null;
		try {
			out = new StringWriter();
			Configuration cfg = new Configuration();
			cfg.setDefaultEncoding("UTF-8");
			Resource resource = new ClassPathResource("templates");
			cfg.setDirectoryForTemplateLoading(new File("/root/templates"));
			// cfg.setDirectoryForTemplateLoading(new File("./templates"));

			Template template = cfg.getTemplate(html);
			template.process(dataModel, out);
			reader = new StringReader(out.toString());
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (out != null) {
				out.close();
			}
		}
		BufferedReader br = new BufferedReader(reader);
		StringBuilder content = new StringBuilder();
		String str = null;
		while ((str = br.readLine()) != null) {
			content.append(str);
		}
		return content.toString();

	}

	public Map<String, Object> buildParam(String questionNo) throws Exception {
		Map<String, Object> dataModel = new HashMap<String, Object>();
		List<QuestionSheet> questionSheetList = new ArrayList<QuestionSheet>();
		// 传入参数
		QuestionSheet questionSheet = new QuestionSheet();
		StudentInfo studentInfo = new StudentInfo();
		Example questionExample = new Example(QuestionSheet.class);
		Criteria questionCriteria = questionExample.createCriteria();
		questionCriteria.andEqualTo("questionNo", questionNo);
		questionSheetList = questionSheetDao.selectByExample(questionExample);
		if (questionSheetList.size() > 0) {
			log.info(">>>>>>查询题单信息 ");
			questionSheet = questionSheetList.get(0);
			questionSheet.setFinishPlanTime((int) Math.ceil(questionSheet.getFinishPlanTime() / (1000 * 60)));
		} else {
			log.info(">>>>>>查询题单信息为空 ");
			dataModel.put("studentInfo", studentInfo);
			dataModel.put("exportDomain", new ArrayList<ExportDomain>());
			dataModel.put("questionSheet", questionSheet);
			dataModel.put("reportDate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
			return dataModel;
		}
		// 更加题单编号获取题目明细
		studentInfo = studentInfoDao.selectByPrimaryKey(questionSheet.getStudentId());
		Example titleDetailExample = new Example(TitleDetail.class);
		Criteria titleDetailCriteria = titleDetailExample.createCriteria();
		titleDetailCriteria.andEqualTo("questionNo", questionSheet.getQuestionNo());
		titleDetailExample.setOrderByClause("diffi_rate asc, rule_no desc");
		List<TitleDetail> titleDetailList = titleDetailDao.selectByExample(titleDetailExample);

		List<ExportDomain> exportDomainList = new ArrayList<ExportDomain>();
		ExportDomain exportDomain = new ExportDomain();
		Map result = new HashMap();
		List<TitleDetail> tempList = new ArrayList<>();
		String lastRuleNo = "";
		int id = 0;
		int maxLen = 0;
		int oneLineoneMin = 32; // 大于32 一行显示一题
		int oneLinetwoMin = 20; // 大于20 小于32 一行显示2题
		int oneLineThreeMin = 12; // 大于14 小于20 一行显示3题
		int oneLineFourMin = 12; // 小于14 一行显示4题
		int typeNum = 0;
		String[] lineString = { "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二", "十三", "十四", "十五", "十六",
				"十七", "十八", "十九", "二十" };
		// 取出所有类别
		for (int i = 0; i < titleDetailList.size(); i++) {
			id++;
			if (!lastRuleNo.equals(titleDetailList.get(i).getRuleNo())) {
				if (i > 0) {
					//log.info(">>>>>>>maxLen  = " + maxLen);
					int lineNum = 0;
					if (maxLen >= oneLineoneMin) {
						lineNum = 1;
					} else if (maxLen >= oneLinetwoMin && maxLen < oneLineoneMin) {
						lineNum = 2;
					} else if (maxLen >= oneLineThreeMin && maxLen < oneLinetwoMin) {
						lineNum = 3;
					} else if (maxLen < oneLineThreeMin) {
						lineNum = 4;
					}
					exportDomain.setTypeNum(lineString[typeNum]);
					exportDomain.setLineNum(lineNum);
					exportDomain.setTitleDetailList(tempList);
					exportDomainList.add(exportDomain);
					tempList = new ArrayList<>();
					exportDomain = new ExportDomain();
					maxLen = 0;
					typeNum++;
				}
				lastRuleNo = titleDetailList.get(i).getRuleNo();
				exportDomain.setRuleNo(titleDetailList.get(i).getRuleNo());
				exportDomain.setRuleName(titleDetailList.get(i).getRuleName());
			}
			// 计算题目的长度
			int perLen = titleDetailList.get(i).getTitleDesc().getBytes("GB2312").length;
			//log.info(titleDetailList.get(i).getTitleDesc() + "  >>>>>>>last maxLen  = " + maxLen);
			if (perLen > maxLen) {
				maxLen = perLen;
			}
			// 根据不同的类型显示输入框
			String replaceStr = "";
			if (titleDetailList.get(i).getTitleType().equals("0")) // 填空题
			{
				replaceStr = "<span style=''>(&nbsp;&nbsp;&nbsp;&nbsp;)</span>";
			} else if (titleDetailList.get(i).getTitleType().equals("1")) // 选择题
			{
				replaceStr = "<span style=''>(&nbsp;&nbsp;&nbsp;&nbsp;)</span>";
				String[] altAnswers;
				String altAnswerStr = "<table  cellspacing='0'   style=' padding:0px; margin: 0px; width:100%;'><tr>";
				altAnswers = titleDetailList.get(i).getAlternativeAnswers().split(";");
				int answerMaxLen = 0;
				int perLineNum = 0;
				for (int j = 0; j < altAnswers.length; j++) {
					if (answerMaxLen < altAnswers[j].getBytes("GB2312").length) {
						answerMaxLen = altAnswers[j].getBytes("GB2312").length;
					}
				}
				if (answerMaxLen >= oneLineoneMin) {
					perLineNum = 1;
				} else if (answerMaxLen >= oneLineThreeMin && answerMaxLen < oneLineoneMin) {
					perLineNum = 2;
				} else if (answerMaxLen < oneLineThreeMin) {
					perLineNum = 4;
				}
				for (int j = 0; j < altAnswers.length; j++) {
					altAnswerStr += "<td style='line-height: 25px; width:" + (100 / perLineNum)
							+ "px;  letter-spacing: 2px;padding-top:10px;'>" + altAnswers[j] + "</td>";
					if ((j + 1) % perLineNum == 0) {
						altAnswerStr += "</tr><tr>";
					}
				}
				altAnswerStr += "</tr></table>";
				altAnswerStr = altAnswerStr.replaceAll("A.", "<span style='font-weight:bold;'>A.&nbsp;&nbsp;</span>");
				altAnswerStr = altAnswerStr.replaceAll("B.", "<span style='font-weight:bold;'>B.&nbsp;&nbsp;</span>");
				altAnswerStr = altAnswerStr.replaceAll("C.", "<span style='font-weight:bold;'>C.&nbsp;&nbsp;</span>");
				altAnswerStr = altAnswerStr.replaceAll("D.", "<span style='font-weight:bold;'>D.&nbsp;&nbsp;</span>");
				titleDetailList.get(i).setAlternativeAnswers(altAnswerStr);
			} else if (titleDetailList.get(i).getTitleType().equals("2")) // 比较题
			{
				replaceStr = "<span style=''>(&nbsp;&nbsp;&nbsp;)</span>";
			} else if (titleDetailList.get(i).getTitleType().equals("3")) // 算式题
			{
				String titlStr = titleDetailList.get(i).getTitleDesc();
				// System.out.println((titlStr.indexOf("{#}")) + "   =======" + titlStr.length());
				replaceStr = "";
				replaceStr = "<span style=''>(&nbsp;&nbsp;&nbsp;)</span>";
				// if ((titlStr.indexOf("{#}") + 3) < titlStr.length()) {
				//
				// }
			}

			titleDetailList.get(i)
					.setTitleDesc(titleDetailList.get(i).getTitleDesc().replaceAll("\\{\\#\\}", replaceStr));
			tempList.add(titleDetailList.get(i));
			// 处理最后一条
			if (i == titleDetailList.size() - 1) {
				//log.info(">>>>>>>last maxLen  = " + maxLen);
				int lineNum = 0;
				if (maxLen >= oneLineoneMin) {
					lineNum = 1;
				} else if (maxLen >= oneLinetwoMin && maxLen < oneLineoneMin) {
					lineNum = 2;
				} else if (maxLen >= oneLineThreeMin && maxLen < oneLinetwoMin) {
					lineNum = 3;
				} else if (maxLen < oneLineThreeMin) {
					lineNum = 4;
				}
				exportDomain.setTypeNum(lineString[typeNum]);
				exportDomain.setLineNum(lineNum);
				exportDomain.setTitleDetailList(tempList);
				exportDomainList.add(exportDomain);
			}
		}
		//log.info(">>>>>>>exportDomainList = ");
		JSONArray jsonArray = new JSONArray(exportDomainList);
		// // System.out.println(">>>"+"abc123".getBytes("GB2312").length);
		// // System.out.println(">>>"+"校园里有水杉树[ ]24棵，松树的棵数是水杉[
		// ]树的3倍。水杉树和松树一共有".getBytes("GB2312").length);
		// // System.out.println(">>>"+"校园里有水杉树24棵，松树的棵数是水杉树的3倍。水杉树和松树一共有多少棵".getBytes("GB2312").length);
		Map<String, String> gradeMap = new HashMap<String, String>();
		gradeMap.put("kindGradeOne", "学龄前");
		gradeMap.put("firstGradeOne", "一年级(上)"); 
		gradeMap.put("firstGradeTwo", "一年级(下)"); 
		gradeMap.put("secondGradeOne", "二年级(上)"); 
		gradeMap.put("secondGradeTwo", "二年级(下)"); 
		gradeMap.put("thirdGradeOne", "三年级(上)"); 
		gradeMap.put("thirdGradeTwo", "三年级(下)"); 
		gradeMap.put("forthGradeOne", "四年级(上)"); 
		gradeMap.put("forthGradeTwo", "四年级(下)"); 
		gradeMap.put("fifthGradeOne", "五年级(上)"); 
		gradeMap.put("fifthGradeTwo", "五年级(下)"); 
		gradeMap.put("sixthGradeOne", "六年级(上)"); 
		gradeMap.put("sixthGradeTwo", "六年级(下)");  
		studentInfo.setClassName(gradeMap.get(studentInfo.getAgeStage()));
		
		dataModel.put("title", "HTML转PDF测试");
		dataModel.put("studentInfo", studentInfo);
		dataModel.put("exportDomain", exportDomainList);
		dataModel.put("questionSheet", questionSheet);
		dataModel.put("reportDate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		dataModel.put("reportUser", "test");
		
	     byte[] fileByte = GetCommonQRcode.genQrCode(questionSheet.getQuestionNo());
		 String s = new BASE64Encoder().encode(fileByte);
		 String img =  "data:image/jpg;base64," + s;
	     dataModel.put("pic", img);
		
		return dataModel;
	}

	// 生成答案区
	public Map<String, Object> buildParamAnswer(String questionNo) throws Exception {
		Map<String, Object> dataModel = new HashMap<String, Object>();
		List<QuestionSheet> questionSheetList = new ArrayList<QuestionSheet>();
		// 传入参数
		QuestionSheet questionSheet = new QuestionSheet();
		StudentInfo studentInfo = new StudentInfo();
		Example questionExample = new Example(QuestionSheet.class);
		Criteria questionCriteria = questionExample.createCriteria();
		questionCriteria.andEqualTo("questionNo", questionNo);
		questionSheetList = questionSheetDao.selectByExample(questionExample);
		if (questionSheetList.size() > 0) {
			log.info(">>>>>>查询题单信息 ");
			questionSheet = questionSheetList.get(0);
			questionSheet.setFinishPlanTime((int) Math.ceil(questionSheet.getFinishPlanTime() / (1000 * 60)));
		} else {
			log.info(">>>>>>查询题单信息为空 ");
			dataModel.put("studentInfo", studentInfo);
			dataModel.put("exportDomain", new ArrayList<ExportDomain>());
			dataModel.put("questionSheet", questionSheet);
			dataModel.put("reportDate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
			return dataModel;
		}
		// 更加题单编号获取题目明细
		studentInfo = studentInfoDao.selectByPrimaryKey(questionSheet.getStudentId());
		Example titleDetailExample = new Example(TitleDetail.class);
		Criteria titleDetailCriteria = titleDetailExample.createCriteria();
		titleDetailCriteria.andEqualTo("questionNo", questionSheet.getQuestionNo());
		titleDetailExample.setOrderByClause("diffi_rate asc, rule_no desc");
		List<TitleDetail> titleDetailList = titleDetailDao.selectByExample(titleDetailExample);

		List<ExportDomain> exportDomainList = new ArrayList<ExportDomain>();
		ExportDomain exportDomain = new ExportDomain();
		Map result = new HashMap();
		List<TitleDetail> tempList = new ArrayList<>();
		String lastRuleNo = "";
		int id = 0;
		int maxLen = 0;
		int oneLineoneMin = 32; // 大于32 一行显示一题
		int oneLinetwoMin = 20; // 大于20 小于32 一行显示2题
		int oneLineThreeMin = 12; // 大于14 小于20 一行显示3题
		int oneLineFourMin = 12; // 小于14 一行显示4题
		int typeNum = 0;
		String[] lineString = { "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二", "十三", "十四", "十五", "十六",
				"十七", "十八", "十九", "二十" };
		// 取出所有类别
		for (int i = 0; i < titleDetailList.size(); i++) {
			id++;
			if (!lastRuleNo.equals(titleDetailList.get(i).getRuleNo())) {
				if (i > 0) {
					//log.info(">>>>>>>maxLen  = " + maxLen);
					int lineNum = 0;
					if (maxLen >= oneLineoneMin) {
						lineNum = 1;
					} else if (maxLen >= oneLinetwoMin && maxLen < oneLineoneMin) {
						lineNum = 2;
					} else if (maxLen >= oneLineThreeMin && maxLen < oneLinetwoMin) {
						lineNum = 3;
					} else if (maxLen < oneLineThreeMin) {
						lineNum = 4;
					}
					exportDomain.setTypeNum(lineString[typeNum]);
					exportDomain.setLineNum(lineNum);
					exportDomain.setTitleDetailList(tempList);
					exportDomainList.add(exportDomain);
					tempList = new ArrayList<>();
					exportDomain = new ExportDomain();
					maxLen = 0;
					typeNum++;
				}
				lastRuleNo = titleDetailList.get(i).getRuleNo();
				exportDomain.setRuleNo(titleDetailList.get(i).getRuleNo());
				exportDomain.setRuleName(titleDetailList.get(i).getRuleName());
			}
			// 计算题目的长度
			int perLen = titleDetailList.get(i).getTitleDesc().getBytes("GB2312").length;
			//log.info(titleDetailList.get(i).getTitleDesc() + "  >>>>>>>last maxLen  = " + maxLen);
			if (perLen > maxLen) {
				maxLen = perLen;
			}
			// 根据不同的类型显示输入框
			String replaceStr = "";

			// 将答案填充到填空区
			String answers = titleDetailList.get(i).getTitleAnswer();
			String[] answerList = answers.split(",");
			String titleDesc = titleDetailList.get(i).getTitleDesc();
			// System.out.println("titleDesc = " + titleDesc);
			// System.out.println("answerList = " + answerList.length);
			for (int j = 0; j < answerList.length; j++) {
				String anStr = answerList[j].replace(">", "&gt;").replace("<", "&lt;");
				titleDesc = titleDesc.replaceFirst("\\{\\#\\}",
						"( <font style='color:red;font-weight:bold;'>" + anStr + "</font> )");
				// System.out.println("begin replace = " + titleDesc);
			}
			titleDetailList.get(i).setTitleDesc(titleDesc);
			tempList.add(titleDetailList.get(i));
			// 处理最后一条
			if (i == titleDetailList.size() - 1) {
				log.info(">>>>>>>last maxLen  = " + maxLen);
				int lineNum = 0;
				if (maxLen >= oneLineoneMin) {
					lineNum = 1;
				} else if (maxLen >= oneLinetwoMin && maxLen < oneLineoneMin) {
					lineNum = 2;
				} else if (maxLen >= oneLineThreeMin && maxLen < oneLinetwoMin) {
					lineNum = 3;
				} else if (maxLen < oneLineThreeMin) {
					lineNum = 4;
				}
				exportDomain.setTypeNum(lineString[typeNum]);
				exportDomain.setLineNum(lineNum);
				exportDomain.setTitleDetailList(tempList);
				exportDomainList.add(exportDomain);
			}
		}
		log.info(">>>>>>>exportDomainList = ");
		JSONArray jsonArray = new JSONArray(exportDomainList);
		// // System.out.println(">>>"+"abc123".getBytes("GB2312").length);
		// // System.out.println(">>>"+"校园里有水杉树[ ]24棵，松树的棵数是水杉[
		// ]树的3倍。水杉树和松树一共有".getBytes("GB2312").length);
		// // System.out.println(">>>"+"校园里有水杉树24棵，松树的棵数是水杉树的3倍。水杉树和松树一共有多少棵".getBytes("GB2312").length);
		//// System.out.println(jsonArray.toString());
		Map<String, String> gradeMap = new HashMap();
		gradeMap.put("kindGradeOne", "学龄前");
		gradeMap.put("firstGradeOne", "一年级(上)"); 
		gradeMap.put("firstGradeTwo", "一年级(下)"); 
		gradeMap.put("secondGradeOne", "二年级(上)"); 
		gradeMap.put("secondGradeTwo", "二年级(下)"); 
		gradeMap.put("thirdGradeOne", "三年级(上)"); 
		gradeMap.put("thirdGradeTwo", "三年级(下)"); 
		gradeMap.put("forthGradeOne", "四年级(上)"); 
		gradeMap.put("forthGradeTwo", "四年级(下)"); 
		gradeMap.put("fifthGradeOne", "五年级(上)"); 
		gradeMap.put("fifthGradeTwo", "五年级(下)"); 
		gradeMap.put("sixthGradeOne", "六年级(上)"); 
		gradeMap.put("sixthGradeTwo", "六年级(下)");  
		studentInfo.setClassName(gradeMap.get(studentInfo.getClassName()));
		
		dataModel.put("title", "HTML转PDF测试");
		dataModel.put("studentInfo", studentInfo);
		dataModel.put("exportDomain", exportDomainList);
		dataModel.put("questionSheet", questionSheet);
		dataModel.put("reportDate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		dataModel.put("reportUser", "test");

		return dataModel;
	}
	/**
	 * 
	 * @param data1
	 * @param data2
	 * @return data1 与 data2拼接的结果
	 */
	public byte[] addBytes(byte[] data1, byte[] data2) {
		byte[] data3 = new byte[data1.length + data2.length];
		System.arraycopy(data1, 0, data3, 0, data1.length);
		System.arraycopy(data2, 0, data3, data1.length, data2.length);
		return data3;
 
	}

}
