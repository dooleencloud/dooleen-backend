package com.dooleen.service.app.file.service;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.FormatType;
import com.aliyuncs.http.HttpResponse;
import com.aliyuncs.imm.model.v20170906.DetectQRCodesRequest;
import com.aliyuncs.profile.DefaultProfile;

public class DetectQRCodes {

	private static String AccessKeyId = "LTAIfvY72ii4QoOH";
	private static String AccessKeySecret = "3zpQUGvvHCkfMGG11De9brov4XRMI7";

	// 项目名称，请确保该项目已经创建
	private static String projectName = "lianxigo";

	// 初始化 IMM 客户端
	private static IAcsClient client = new DefaultAcsClient(
			DefaultProfile.getProfile("cn-hangzhou", AccessKeyId, AccessKeySecret));

	public static void main(String[] args) throws ClientException {
		// 调用文档转换请求
		docConvertDemo();
	}

	public static void docConvertDemo() throws ClientException {
		DetectQRCodesRequest req = new DetectQRCodesRequest();
		// DetectQRCodesResponseUnmarshaller qrRes = new
		// DetectQRCodesResponseUnmarshaller();
		// UnmarshallerContext _ctx = new UnmarshallerContext();
		req.setAcceptFormat(FormatType.JSON);
		req.setProject(projectName);
		req.setSrcUris("[\"oss://dooleen-hangzhou/1.png\"]");
		req.setVersion("2017-09-06");
		HttpResponse resp = client.doAction(req);
		// DetectQRCodesResponse res = client.getAcsResponse(req);
		String respStr = resp.getHttpContentString();

		Map<String, Object> respMap = new HashMap<String, Object>();
		respMap = JSON.parseObject(respStr);
		System.out.println(respMap.get("SuccessDetails"));
		System.out.println(respMap.get("FailDetails"));
	}
}
