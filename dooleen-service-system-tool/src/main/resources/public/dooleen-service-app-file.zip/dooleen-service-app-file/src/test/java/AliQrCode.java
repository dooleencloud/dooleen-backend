import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.imm.model.v20170906.*;
import com.aliyuncs.profile.DefaultProfile;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.aliyun.oss.OSS;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import sun.misc.BASE64Encoder;

public class AliQrCode {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private static final String ENCODING = "UTF-8";
	
    public static final String Format = "JSON";
    public static final String VERSION = "2017-09-06";
    public static final String AccessKeyId = "LTAIfvY72ii4QoOH";//填写你的key
    public static final String AccessKeySecret = "3zpQUGvvHCkfMGG11De9brov4XRMI7";//填写你的Secret
    public static final String Signature = "";
    public static final String SignatureMethod = "HMAC-SHA1";
    public static final String Project = "lianxigo";
    public static final String Timestamp = getUTCTimeStr();
    public static final String SignatureVersion = "1.0";
//    public static final String SignatureNonce = RandomUtils.generateString32(12);
	
	private static String accessKeyId = "LTAIfvY72ii4QoOH";
	private static String accessKeySecret = "3zpQUGvvHCkfMGG11De9brov4XRMI7";
	
    // 初始化 IMM 客户端
    static IAcsClient client = new DefaultAcsClient(DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret));
    
    // 项目名称，请确保该项目已经创建
    static String projectName = "lianxigo";
    
    public static void main(String[] args) throws ClientException, IOException {
        // 调用文档转换请求
//        docConvertDemo();
    	qrDecode();
    }
    public static void docConvertDemo() throws ClientException{
        // 创建文档转换异步请求任务
        CreateOfficeConversionTaskRequest req = new CreateOfficeConversionTaskRequest();
        req.setProject(projectName);
        // 设置待转换对文件OSS路径
        req.setSrcUri("oss://preview-office-bucket/docs/input/demo.pptx");
        // 设置文件输出格式为 vector
        req.setTgtType("vector");
        // 设置转换后的输出路径
        req.setTgtUri("oss://preview-office-bucket/docs/output/demo_pptx");
        CreateOfficeConversionTaskResponse res = client.getAcsResponse(req);
        String taskId = res.getTaskId();
        // 获取文档转换任务结果，最多轮询 30 次
        // 每次轮询的间隔为 1 秒
        GetOfficeConversionTaskRequest getOfficeConversionTaskRequest = new GetOfficeConversionTaskRequest();
        getOfficeConversionTaskRequest.setProject(projectName);
        getOfficeConversionTaskRequest.setTaskId(taskId);
        int maxCount = 30;
        int count = 0;
        try {
            while (true) {
                Thread.sleep(1000); // 1 秒
                GetOfficeConversionTaskResponse getOfficeConversionTaskResponse = client.getAcsResponse(getOfficeConversionTaskRequest);
                if (!getOfficeConversionTaskResponse.getStatus().equals("Running")) {
                    // 输出文档转换任务执行结果
                    System.out.println(getOfficeConversionTaskResponse.getTaskId());
                    System.out.println(getOfficeConversionTaskResponse.getFailDetail().getCode());
                    System.out.println("Done");
                    break;
                }
                count = count + 1;
                if(count >= maxCount) {
                    System.out.println("OfficeConversion Timeout for 30 seconds");
                    break;
                }
                System.out.println("Task is still running.");
            }
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }
    
    
    public static String qrDecode() throws MalformedURLException, ProtocolException, IOException {
    	
    	//URL
    	String url = "https://imm.cn-hangzhou.aliyuncs.com";
    	

//        TimeZone tz1 = TimeZone.getTimeZone("Asia/Shanghai");
//		//TimeZone tz = TimeZone.getTimeZone("GMT-01");
//        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");  
//        df.setTimeZone(tz1);  
//        String nowAsISO = df.format(new Date());  
//        System.out.println(nowAsISO);
    	
//    	TimeZone tz = TimeZone.getTimeZone("Asia/Shanghai");
    	TimeZone tz = TimeZone.getTimeZone("UTC");
    	DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		sdf.setTimeZone(tz);
		Date now = new Date();
		String nowStr = sdf.format(now);
		//版本号
    	String format = Format;   	
    	url += "?Format=" + format;
		//版本号
    	String version = "2017-09-06";   	
    	url += "&Version=" + version;
    	//
    	String accessKeyId = "LTAIfvY72ii4QoOH";
    	url += "&AccessKeyId=" + accessKeyId;
//    	//签名结果串
//    	String signature = percentEncode(accessKeyId);
//    	System.out.println("signature: " + signature);
//    	url += "&Signature=" + signature;
    	//签名方法
    	String signatureMethod = SignatureMethod;
    	url += "&SignatureMethod=" + signatureMethod;
    	System.out.println(nowStr);
    	//请求时间戳
    	String timestamp = Timestamp;
    	url += "&Timestamp=" + timestamp;
    	//签名算法版本
    	String signatureVersion = SignatureVersion;
    	url += "&SignatureVersion=" + signatureVersion;
    	//唯一随机数
    	Random random = new Random(1);
    	String signatureNonce = String.valueOf(random.nextInt(999999999));
    	url += "&SignatureNonce=" + signatureNonce;
    	//操作码
    	String action = "DetectQRCodes";
    	url += "&Action=" + action;
    	//项目名
    	String project = Project;
    	url += "&Project=" + project;
    	//图片地址
    	String srcUris = "[\"oss://dooleen-hangzhou/1.png\"]";
//    	String srcUris = "[\"https://mymirror-1259592194.cos.ap-chengdu.myqcloud.com/examFile/3.jpg\"]";
    	url += "&SrcUris=" + srcUris;
    	
    	
    	
    	//签名结果串
    	String stringToSign = getSignature(signatureNonce, timestamp, action, srcUris);
    	String signature = stringToSign;
    	System.out.println("signature: " + signature);
    	url += "&Signature=" + signature;
    	
    	URL requestUrl = new URL(url);
		HttpsURLConnection conn = (HttpsURLConnection) requestUrl.openConnection();
		conn.setDoOutput(true);
		conn.setDoInput(true);
		conn.setUseCaches(false);
		// 设置请求方式（GET/POST）
		conn.setRequestMethod("POST");
		conn.setRequestProperty("content-type", "application/x-www-form-urlencoded");
		// 当outputStr不为null时向输出流写数据
//		if (null != outputStr) {
		JSONObject json = new JSONObject();
			OutputStream outputStream = conn.getOutputStream();
			// 注意编码格式
			outputStream.write(json.toString().getBytes("UTF-8"));
			outputStream.close();
//		}
		// 从输入流读取返回内容
		InputStream inputStream = conn.getInputStream();
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		String str = null;
		StringBuffer buffer = new StringBuffer();
		while ((str = bufferedReader.readLine()) != null) {
			buffer.append(str);
		}
		// 释放资源
		bufferedReader.close();
		inputStreamReader.close();
		inputStream.close();
		inputStream = null;
		conn.disconnect();
		return buffer.toString();
    	
    }
    
    private static String percentEncode(String value) throws UnsupportedEncodingException {
    	return value != null ? URLEncoder.encode(value, ENCODING).replace("+", "%20").replace("*", "%2A").replace("%7E", "~") : null;
    }
    
    private static final String ISO8601_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    
    public static String getUTCTimeStr() {
        //1、取得本地时间：
        final java.util.Calendar cal = java.util.Calendar.getInstance();
        System.out.println(cal.getTime());
        //2、取得时间偏移量：
        final int zoneOffset = cal.get(java.util.Calendar.ZONE_OFFSET);
        System.out.println(zoneOffset);
        //3、取得夏令时差：
        final int dstOffset = cal.get(java.util.Calendar.DST_OFFSET);
        System.out.println(dstOffset);
        //4、从本地时间里扣除这些差量，即可以取得UTC时间：
        cal.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset));
        SimpleDateFormat df = new SimpleDateFormat(ISO8601_DATE_FORMAT);
        return df.format(cal.getTime());
    }
    
    public static String getSignature(String SignatureNonce, String Timestamp, String action, String srcUris) {
        String signature = "";
        try {
            Map<String, String> parameters = new HashMap<String, String>();
            parameters.put("Format", Format);
            parameters.put("Version", VERSION);
            parameters.put("AccessKeyId", AccessKeyId);
            parameters.put("SignatureMethod", SignatureMethod);
            parameters.put("Timestamp", Timestamp);
            parameters.put("SignatureVersion", SignatureVersion);
            parameters.put("Project", Project);
            parameters.put("SignatureNonce", SignatureNonce);

            parameters.put("Action", action);
            parameters.put("SrcUris", srcUris);
            

            // 对参数进行排序
            String[] sortedKeys = (String[]) parameters.keySet().toArray(new String[]{});
            Arrays.sort(sortedKeys);
            final String SEPARATOR = "&";
            // 生成stringToSign字符串
            StringBuilder stringToSign = new StringBuilder();

            stringToSign.append("POST").append(SEPARATOR).append(percentEncode("/")).append(SEPARATOR);

//            stringToSign.append(percentEncode("/")).append(SEPARATOR);

            StringBuilder canonicalizedQueryString = new StringBuilder();

            for (String key : sortedKeys) {
                // 这里注意对key和value进行编码
                canonicalizedQueryString.append("&").append(percentEncode(key))
                        .append("=").append(percentEncode((String) parameters.get(key)));
            }
            // 这里注意对canonicalizedQueryString进行编码
            stringToSign.append(percentEncode(canonicalizedQueryString.toString()
                    .substring(1)));
            System.out.println("----------stringToSign: " + stringToSign.toString());
            final String ALGORITHM = "HmacSHA1";
            final String ENCODING = "UTF-8";
            String key = AccessKeySecret + "&";
            Mac mac = Mac.getInstance(ALGORITHM);
            mac.init(new SecretKeySpec(key.getBytes(ENCODING), ALGORITHM));
            byte[] signData = mac.doFinal(stringToSign.toString().getBytes(ENCODING));
            signature = new String(new BASE64Encoder().encode(signData));
            signature = percentEncode(signature);
            System.out.println("----------signature: " + signature);
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        return signature;
    }
    
//    public void uploadFile() {
//    	// Endpoint以杭州为例，其它Region请按实际情况填写。
//    	String endpoint = "http://oss-cn-hangzhou.aliyuncs.com";
//    	// 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建RAM账号。
//    	String accessKeyId = "<yourAccessKeyId>";
//    	String accessKeySecret = "<yourAccessKeySecret>";
//    	String bucketName = "<yourBucketName>";
//    	String objectName = "<yourObjectName>";
//
//    	// 创建OSSClient实例。
//    	OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
//
//    	// 上传内容到指定的存储空间（bucketName）并保存为指定的文件名称（objectName）。
//    	String content = "Hello OSS";
//    	ossClient.putObject(bucketName, objectName, new ByteArrayInputStream(content.getBytes()));
//
//    	// 关闭OSSClient。
//    	ossClient.shutdown();
//    }
}
