//package com.dooleen.service.app.file.service;
//
//import java.awt.image.BufferedImage;
//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.InputStream;
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Random;
//
//import javax.imageio.ImageIO;
//
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.rendering.ImageType;
//import org.apache.pdfbox.rendering.PDFRenderer;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//import org.springframework.transaction.interceptor.TransactionAspectSupport;
//
//import com.aspose.words.ControlChar;
//import com.aspose.words.Document;
//import com.aspose.words.DocumentBuilder;
//import com.aspose.words.FieldType;
//import com.aspose.words.HeaderFooterType;
//import com.aspose.words.License;
//import com.aspose.words.SaveFormat;
//import com.aspose.words.TabAlignment;
//import com.aspose.words.TabLeader;
//import com.aspose.words.Underline;
//import com.dooleen.common.core.entity.FileData;
//import com.dooleen.common.core.utils.DateUtils;
//import com.dooleen.common.core.utils.EntityInitUtils;
//import com.dooleen.common.core.utils.GenerateNo;
//import com.dooleen.service.app.file.dao.FileDataDao;
//import com.qcloud.cos.COSClient;
//import com.qcloud.cos.ClientConfig;
//import com.qcloud.cos.auth.BasicCOSCredentials;
//import com.qcloud.cos.auth.COSCredentials;
//import com.qcloud.cos.model.ObjectMetadata;
//import com.qcloud.cos.region.Region;
//
//import sun.misc.BASE64Encoder;
//
///**
// * 
// * 由于ASPOSE比较吃内存，操作大一点的文件就会堆溢出，所以请先设置好java虚拟机参数：-Xms1024m -Xmx1024m(参考值)<br>
// * 
// * 
// * @author liqh
// *
// */
//@Service
//@Transactional(rollbackFor = Exception.class)
//public class ConvertWordToPdf {
//	private static final Logger logger = LoggerFactory.getLogger(ConvertWordToPdf.class);
//
//	private String secretId = "AKIDJRK4aqmDE0Wmogsl26uTnrhIhxxi7TVJ";
//	private String secretKey = "iEZfV5QVO2UjkV3LODnBNL3VifQwGOIw";
//	private static InputStream license;
//	private static InputStream fileInput;
//	private static File outputFile;
//
//	@Autowired
//	private GenerateNo genNo;
//	@Autowired
//	private FileDataDao fileDataDao;
//
//	/**
//	 * 
//	 * @param args
//	 */
//	public List convertWordToPdf(String inFilePath, String outPutFilePath, String collName,String model) {
//		// 验证License
//		String nowDate = DateUtils.getCurTimestamp().toString();
//		String expFile = "";
//		String outFilePath = outPutFilePath;
//		List resutArray = new ArrayList<>();
//		if (!getLicense()) {
//			resutArray.add("获取许可异常！");
//			return resutArray;
//		}
//		try {
//			ClassLoader loader = Thread.currentThread().getContextClassLoader();
//			// File file=new File("/root/xunfei/北师大版数学一年级上学期期末试卷1（猪猪喜羊羊）.doc");
//			long old = System.currentTimeMillis();
//			List<File> files = getFiles(inFilePath);
//			for (File file : files) {
//				String fileType = file.getName().substring(file.getName().lastIndexOf(".") + 1).toUpperCase();
//				if (fileType.equals("DOC") || fileType.equals("DOCX")) {
//					fileInput = new FileInputStream(file); // 待处理的文件
//					String outFileName =  file.getName().replace(".docx", ".pdf")
//							.replace(".doc", ".pdf")
//							.replace("（猪猪喜羊羊）", "")
//							.replace("(猪猪喜羊羊)", "")
//							.replace("猪猪喜羊羊", "");
//					if( outPutFilePath == null || outPutFilePath.trim().equals(""))
//					{
//						outFilePath = file.getParent()+"-PDF";
//					}
//					String outPath = outFilePath + "/" + outFileName;
//					expFile = outPath;
//					outputFile = new File(outPath); 
//					System.out.println("outputFile = " + outFilePath);
//					Document doc = new Document(fileInput);
//					doc.getRange().replace("喜子的商铺(淘宝店)：", "", true, false);
//					doc.getRange().replace("喜子的商5铺(淘宝店)：", "", true, false);
//					doc.getRange().replace("喜子的商", "", true, false);
//					doc.getRange().replace("淘宝店", "", true, false);
//					doc.getRange().replace("http://t.cn/Ri466E4", "", true, false);
//					doc.getRange().replace("微店:", "", true, false);
//					doc.getRange().replace("http://shop83755268.vpubao.com/", "", true, false);
//					doc.getRange().replace("http://www.xkb1.com/", "", true, false);
//					doc.getRange().replace("http://www.xkb1.com", "", true, false);
//					doc.getRange().replace("https://www.xkb1.com/", "", true, false);
//					doc.getRange().replace("新- 课- 标-第- 一- 网", "", true, false);
//					doc.getRange().replace("新-", "", true, false);
//					doc.getRange().replace("课-", "", true, false);
//					doc.getRange().replace("标-第", "", true, false);
//					doc.getRange().replace("一- 网", "", true, false);
//					doc.getRange().replace("X  k B  1 .  c o m", "", true, false);
//					doc.getRange().replace("XkB1", "", true, false);
//					doc.getRange().replace("com", "", true, false);
//					doc.getRange().replace("c o m", "", true, false);
//					doc.getRange().replace("标-", "", true, false);
//					doc.getRange().replace("第-", "", true, false);
//					
//					
//					doc.getFirstSection().clearHeadersFooters();
//
//		            File outSavePath = new File(outFilePath);  
//		            if ( !outSavePath.exists()){//若此目录不存在，则创建之  
//		            	outSavePath.mkdir();  
//		                System.out.println("创建文件夹路径为："+ outFilePath);  
//		            }  
//					
//					FileOutputStream fileOS = new FileOutputStream(outputFile);
//					DocumentBuilder builder = new DocumentBuilder(doc);
//					
//					// 设置移动到页面最底下
//
//					//builder.moveToDocumentEnd();
//
//					// 设置奇数页和偶数页页眉页脚
//
//					builder.getPageSetup().setOddAndEvenPagesHeaderFooter(false);
//
//					// 设置除第一页外的页眉页脚
//					//builder.getPageSetup().setFirstPageTray(0);
//					builder.getPageSetup().setDifferentFirstPageHeaderFooter(false);
//					// builder.getPageSetup().setHeaderDistance(5);
//					// builder.getPageSetup().setFooterDistance(10);
//					// builder.getPageSetup().setPageHeight(950);
//					// builder.getPageSetup().setPageNumberStyle(2);
//					// 设置移动到页眉和页脚
//					builder.moveToHeaderFooter(HeaderFooterType.HEADER_PRIMARY);
//					builder.moveToDocumentStart();
//					// 设置字体
//					//builder.getFont().setSize(14);
//					if (collName == null || collName.equals("")) {
//						collName = "由练习GO收集整理";
//					}
//					String fileNo = genNo.getUniversalNo();
//					byte[] fileByte = GetCommonQRcode.genQrCode(fileNo);
//					String s = new BASE64Encoder().encode(fileByte);
//					String img = "data:image/jpg;base64," + s;
//
//					String html = "<div style='width:100%; margin-bottom:20px;'>"
//							+ "<table cellpadding='0' cellspacing='0' style='border:0px; padding:0px; margin:0px; width:100%; float:left;'>" + "<tr>"
//							+ "<td style='border-bottom:1px dashed #636363;width:205px;text-align:left'><img style='width:130px;height:50px;' src='https://imgfile.dooleen.com.cn/images/pdfImg/go.png'/><img style='width:70px;height:70px;' src='https://imgfile.dooleen.com.cn/images/pdfImg/qrcode.jpg'/></td>"
//							+ "<td style=\"font-size:14px; border-bottom:1px dashed #636363;text-align:center;font-famliy:'宋体'; vertical-align:bottom;\">"
//							+ collName + "</td>"
//							+ "<td style='border-bottom:1px dashed #636363;width:150px;text-align: right'><img style='width:70px;height:70px;' src='"
//							+ img + "'/></td>" + "</tr>" + "</table>" + "</div>";
//					// System.out.println(html);
//					builder.insertHtml(html);
//					// builder.write("练习GO");
//
//					// 设置移动到页脚
//					builder.moveToHeaderFooter(HeaderFooterType.FOOTER_PRIMARY);
//					// 设置字体
//					builder.getFont().setName("宋体");
//					builder.getFont().setBold(true);
//					builder.getFont().setSize(10); 
//					html = "<div style='width:100%; margin-bottom:20px;'>"
//							+ "<table cellpadding='0' cellspacing='0' style='border:0px; padding:0px; margin:0px; width:100%; float:left;'>" + "<tr>"
//							+ "<td style='padding-top:10px;font-size:12px;border-top:1px solid #333333;width:100%;text-align: right'>更多资料请关注公众号：练习GO</td>"
//							+ "</tr>" + "</table>" + "</div>";
//					builder.insertHtml(html);
//					// builder.write("练习GO");
//					// doc.getFirstSection().clearHeadersFooters();// .add(footer);
//					// doc.getFirstSection().getHeadersFooters().add(footer);
//					 //Set start number
//					builder.getPageSetup().setFooterDistance(15);
//					builder.getParagraphFormat().getTabStops().add(474.9, TabAlignment.LEFT, TabLeader.NONE);
//					
//					builder.write("第");
//					builder.insertField(FieldType.FIELD_PAGE, false);
//					builder.write("页 共");
//					builder.insertField(FieldType.FIELD_NUM_PAGES, false);
//					builder.write("页 "); 
//					doc.updateFields();
//					doc.save(fileOS, SaveFormat.PDF);
//					String fileImgUrl = "https://imgfile.dooleen.com.cn/examimg" + outPath.replace(".pdf", ".jpg");
//					if(model.equals("1"))
//					{
//						pdfToImage(outFilePath+"/"+outFileName, outPath.replace(".pdf", ".jpg"));
//					}
//					resutArray.add(fileNo + "#" + outFileName + "#"+ outPath +"#"+ fileImgUrl+ "#转化PDF成功！");
//				}
//			}
//			// 处理日志
//			if(model.equals("1"))
//			{
//				
//				for (int i = 0; i < resutArray.size(); i++) {
//					
//					String[] fileFiled = resutArray.get(i).toString().split("#");
//					String verFlag = "";
//					String grade = "";
//					String stage = "";
//					//版本
//					if(fileFiled[2].indexOf("北师大") > 0)
//					{
//						verFlag = "北师大版";
//					}
//					else if(fileFiled[2].indexOf("人教版") > 0)
//					{
//						verFlag = "人教版";
//					}
//					else if(fileFiled[2].indexOf("苏教版") > 0)
//					{
//						verFlag = "苏教版";
//					}
//					//单元 期中 期末
//					if(fileFiled[1].indexOf("期末") > 0)
//					{
//						stage = "期末";
//					}
//					else if(fileFiled[1].indexOf("期中") > 0)
//					{
//						stage = "期中";
//					}
//					else if(fileFiled[1].indexOf("单元") > 0)
//					{
//						stage = "单元测试";
//					}
//					else if(fileFiled[1].indexOf("同步") > 0)
//					{
//						stage = "同步练习";
//					}
//					//年级
//					if(fileFiled[2].indexOf("学龄前") > 0)
//					{
//						grade = "kindGradeOne";
//					}
//					else if(fileFiled[2].indexOf("一年级上") > 0)
//					{
//						grade = "firstGradeOne";
//					}
//					else if(fileFiled[2].indexOf("一年级下") > 0)
//					{
//						grade = "firstGradeTwo";
//					}
//					else  if(fileFiled[2].indexOf("二年级上") > 0)
//					{
//						grade = "secondGradeOne";
//					}
//					else if(fileFiled[2].indexOf("二年级下") > 0)
//					{
//						grade = "secondGradeTwo";
//					}
//					else  if(fileFiled[2].indexOf("三年级上") > 0)
//					{
//						grade = "thirdGradeOne";
//					}
//					else if(fileFiled[2].indexOf("三年级下") > 0)
//					{
//						grade = "thirdGradeTwo";
//					}
//					else  if(fileFiled[2].indexOf("四年级上") > 0)
//					{
//						grade = "forthGradeOne";
//					}
//					else if(fileFiled[2].indexOf("四年级下") > 0)
//					{
//						grade = "forthGradeTwo";
//					}
//					else  if(fileFiled[2].indexOf("五年级上") > 0)
//					{
//						grade = "fifthGradeOne";
//					}
//					else if(fileFiled[2].indexOf("五年级下") > 0)
//					{
//						grade = "fifthGradeTwo";
//					}
//					else  if(fileFiled[2].indexOf("六年级上") > 0)
//					{
//						grade = "sixthGradeOne";
//					}
//					else if(fileFiled[2].indexOf("六年级下") > 0)
//					{
//						grade = "sixthGradeTwo";
//					}
//					FileData fileData = new FileData();
//					fileData.setFileDataNo(fileFiled[0]);
//					fileData.setFileName(fileFiled[1]);
//					fileData.setFileDataUrl(fileFiled[2]);
//					fileData.setFileDataPic(fileFiled[3]);
//					fileData.setCreateDatetime(nowDate);
//					fileData.setFileSource("1");
//					fileData.setFileType("0");
//					fileData.setFilePrice(new BigDecimal(1000));
//					fileData.setUserId("999999");
//					fileData.setSubjectNo("0");
//					fileData.setLabel(verFlag);
//					fileData.setOpenFlag("1");
//					fileData.setEffectFlag("1");
//					fileData.setRewardTo("1");
//					fileData.setStage(stage);
//					fileData.setFinishPlanTime(3600000);
//					fileData.setGrade(grade);
//					fileData.setUnlockNum(2);
//					fileData.setDownloadNum(new Random().nextInt(10000) + 1000);
//					fileData.setDiffiRate(2);
//					fileData.setCreateName("system01"); 
//					fileData.setCreateId("999999");
//					fileData.setUpdateDatetime(nowDate);
//					fileData.setUpdateName("system01");
//					fileData.setUpdateId("999999");
//					int index = fileDataDao
//							.insertSelective(EntityInitUtils.initEntityPublicInfoForUpdate(fileData, fileData.getUserId()));
//					if (index < 1) {
//						resutArray.add(fileData.getFileName() + "插入数据库异常！");
//					}
//				}
//			}
//			resutArray.add("====end====");
//			// fileDataDao;
//			long now = System.currentTimeMillis();
//			resutArray.add("创建时间：" + nowDate);
//			resutArray.add("共耗时：" + ((now - old) / 1000.0) + "秒\n\n" + "文件保存在:" + outFilePath);
//			System.out.println("共耗时：" + ((now - old) / 1000.0) + "秒\n\n" + "文件保存在:");
//		} catch (Exception e) {
//			resutArray.add(expFile + "文件转化异常");
//			resutArray.add(e.toString());
//			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//			e.printStackTrace();
//		}
//		return resutArray;
//	}
//
//	/**
//	 * 获取license
//	 * 
//	 * @return
//	 */
//	public static boolean getLicense() {
//		boolean result = false;
//		try {
//			ClassLoader loader = Thread.currentThread().getContextClassLoader();
//			license = new FileInputStream(loader.getResource("license.xml").getPath());// 凭证文件
//			License aposeLic = new License();
//			aposeLic.setLicense(license);
//			result = true;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return result;
//	}
//
//	public static List<File> getFiles(String path) {
//		File root = new File(path);
//		List<File> files = new ArrayList<File>();
//		if (!root.isDirectory()) {
//			files.add(root);
//		} else {
//			File[] subFiles = root.listFiles();
//			for (File f : subFiles) {
//				files.addAll(getFiles(f.getAbsolutePath()));
//			}
//		}
//		return files;
//	}
//
//	/**
//	 * pdf转图片
//	 *
//	 * @param pdfPath
//	 *            PDF路径
//	 * @return 图片路径
//	 */
//	public void pdfToImage(String pdfPath, String fileName) {
//		// 经过测试,dpi为96,100,105,120,150,200中,105显示效果较为清晰,体积稳定,dpi越高图片体积越大,一般电脑显示分辨率为96
//		float DEFAULT_DPI = 105;
//		// 默认转换的图片格式为jpg
//		String DEFAULT_FORMAT = "jpg";
//		try {
//
//			System.setProperty("sun.java2d.cmm", "sun.java2d.cmm.kcms.KcmsServiceProvider");
//			// 图像合并使用参数
//			// 总宽度
//			int width = 0;
//			// 保存一张图片中的RGB数据
//			int[] singleImgRGB;
//			int shiftHeight = 0;
//			// 保存每张图片的像素值
//			BufferedImage imageResult = null;
//			// 利用PdfBox生成图像
//			PDDocument pdDocument = PDDocument.load(new File(pdfPath));
//			PDFRenderer renderer = new PDFRenderer(pdDocument);
//			// 循环每个页码
//			for (int i = 0, len = pdDocument.getNumberOfPages(); i < 1; i++) {
//				BufferedImage image = renderer.renderImageWithDPI(i, DEFAULT_DPI, ImageType.RGB);
//				int imageHeight = image.getHeight();
//				int imageWidth = image.getWidth();
//				// 计算高度和偏移量
//				if (i == 0) {
//					// 使用第一张图片宽度;
//					width = imageWidth;
//					// 保存每页图片的像素值
//					imageResult = new BufferedImage(width, imageHeight * 1, BufferedImage.TYPE_INT_RGB);
//				} else {
//					// 计算偏移高度
//					shiftHeight += imageHeight;
//				}
//				singleImgRGB = image.getRGB(0, 0, width, imageHeight, null, 0, width);
//				// 写入流中
//				imageResult.setRGB(0, shiftHeight, width, imageHeight, singleImgRGB, 0, width);
//			}
//			pdDocument.close();
//			// 写图片
//			ByteArrayOutputStream byteFile = new ByteArrayOutputStream();
//			ImageIO.write(imageResult, DEFAULT_FORMAT, byteFile);
//			//传到COS
//			uploadFile(byteFile.toByteArray(),fileName);
//		} catch (Exception e) {
//			logger.error("PDF转图片失败");
//			e.printStackTrace();
//		} 
//	}
//
//	// 图片存入腾讯COS中
//	public String uploadFile(byte[] bytes, String fName) throws Exception {
//		// 1 初始化用户身份信息（secretId, secretKey）。
//		COSCredentials cred = new BasicCOSCredentials(secretId, secretKey);
//		// 2 设置 bucket 的区域, COS 地域的简称请参照
//		// https://cloud.tencent.com/document/product/436/6224
//		// clientConfig 中包含了设置 region, https(默认 http), 超时, 代理等 set 方法, 使用可参见源码或者常见问题
//		// Java SDK 部分。
//		Region region = new Region("ap-chengdu");
//		ClientConfig clientConfig = new ClientConfig(region);
//		// 3 生成 cos 客户端。
//		COSClient cosClient = new COSClient(cred, clientConfig);
//		// 方法1 将本地文件上传到 COS
//		String bucketName = "dooleenv1-1259592194";
//		String fileName = "examimg" + fName;
//		// 获取文件流
//		int length = bytes.length;
//		InputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
//		ObjectMetadata objectMetadata = new ObjectMetadata();
//		// 从输入流上传必须制定content length, 否则http客户端可能会缓存所有数据，存在内存OOM的情况
//		objectMetadata.setContentLength(length);
//		// 默认下载时根据cos路径key的后缀返回响应的contenttype, 上传时设置contenttype会覆盖默认值
//		// objectMetadata.setContentType("image/jpeg");
//		cosClient.putObject(bucketName, fileName, byteArrayInputStream, objectMetadata).getRequestId();
//		return fileName;
//	}
//}