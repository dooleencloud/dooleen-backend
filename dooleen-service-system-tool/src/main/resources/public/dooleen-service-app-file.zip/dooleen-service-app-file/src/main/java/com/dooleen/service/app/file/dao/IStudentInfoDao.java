package com.dooleen.service.app.file.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.dooleen.common.core.entity.StudentInfo;
import com.dooleen.common.core.entity.UserRelation;
import com.dooleen.common.core.tkMapper.TkMapper;

public interface IStudentInfoDao extends TkMapper<StudentInfo>{
	@Select("select a.user_id  'userId', a.mobile_no 'mobileNo', a.user_name 'userName',a.full_name 'fullName', a.user_role 'userRole',a.open_id 'openId',a.nick_name 'nickName' ,a.head_url 'headUrl',a.sex 'sex',a.age_stage 'ageStage',a.age 'age',a.school_name 'schoolName',"
			+ " a.class_name 'className', a.class_no 'classNo', a.birthday 'birthday', a.honor 'honor', a.medal 'medal', a.hobby 'hobby', a.perday_use_max 'perdayUseMax' , a.per_use_max 'perUseMax', a.allow_shop_flag 'allowShopFlag' from  student_info a,  user_relation b "
			+ "where b.parent_id = #{userId}  and a.user_id = b.student_id")
	List<StudentInfo>  selectStudentInfo(@Param("userId") String userId);
}