#!/bin/sh

cd /root/dooleen/dooleen-service-app-file
pwd
. cd /root/dooleen/dooleen-service-app-file

export JAVA_HOME=/usr/local/java/jdk1.8.0_161
export PATH=$JAVA_HOME/bin:$PATH

java -jar -Xmx128m -Xms128m -Dloader.path=.,/root/dooleen/applib dooleen-service-app-file-1.0.0-SNAPSHOT.jar --spring.profiles.active=$1 > /dev/null &
echo $! > /root/dooleen/data/dooleen-service-app-file.pid