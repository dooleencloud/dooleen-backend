package com.dooleen.service.app.file.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dooleen.common.core.common.entity.CommonMsg;
import com.dooleen.common.core.common.entity.NullEntity;
import com.dooleen.common.core.entity.vo.FileDataRequest;
import com.dooleen.common.core.utils.GenTransSeqNo;
import com.dooleen.common.core.utils.SetChainPathUtils;
import com.dooleen.service.app.file.entity.SendEmailPdf;
//import com.dooleen.service.app.file.service.ConvertWordToPdf;
import com.dooleen.service.app.file.service.CosSerevice;
import com.dooleen.service.app.file.service.PdfExportOssService;
import com.dooleen.service.app.file.service.PdfExportService;
import com.dooleen.service.app.file.service.SendEmailService;

import io.swagger.annotations.ApiOperation;

/**
 * @Copy Right Information : 神口算
 * @Project : 神口算
 * @Project No :dooleen
 * @Description : 修改用户信息
 * @Author : XX
 * @Version : 1.0.0
 * @Since : 1.0
 * @CreateDate : 2019-07-01 10:00:01 +++++++++++++maintainer1 info+++++++++++++
 * @Description : 修改用户信息
 * @Maintainer:
 * @Update:
 */
@RestController
@RequestMapping("/fileApi/file")
public class FileController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private PdfExportService pdfExportService;
	@Autowired
	private PdfExportOssService pdfExportOssService;
	
	@Autowired
	private SendEmailService sendEmailService;
	
	@Resource
	private JavaMailSender javaMailSender;
	@Autowired
	private CosSerevice cosSerevice;
//	@Autowired
//	private ConvertWordToPdf convertWordToPdf;
	@RequestMapping(value = "/previewPdf", method = RequestMethod.GET)
	public byte[] genExamPdf(@RequestParam String questionNo, HttpServletResponse response) {
		response.setContentType("application/pdf");
 		byte[] rep = null;
 		logger.info(">>开始执行预览PDF，交易流水号：taskNo =" + questionNo + "，path=" + this.getClass()); 
		try {
			rep = pdfExportService.genExamPdf(questionNo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
		//logger.info(">>用户信息修改结束，交易流水号：" + commonMsg.getHead().getTransSeqNo()+ ",path="+ this.getClass()); 
		return rep;
	}
	
	@RequestMapping(value = "/sendPdfEmail", method = RequestMethod.POST)
	public String sendPdfEmail(@RequestBody CommonMsg<SendEmailPdf,NullEntity> commonMsg) {
		
 		String rep = null;
 		logger.info(">>开始发送PDF邮件，交易流水号：" + commonMsg.getHead().getTransSeqNo() + "，path=" + this.getClass()); 
		logger.debug(">>传入参数head："
				+ ReflectionToStringBuilder.toString(commonMsg.getHead(), ToStringStyle.MULTI_LINE_STYLE));
		logger.debug(">>传入参数body：" + ReflectionToStringBuilder.toString(commonMsg.getBody(),
				ToStringStyle.MULTI_LINE_STYLE));
	    try {
			rep = pdfExportService.sendMailExamPdf(javaMailSender,commonMsg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logger.info(">>发送PDF邮件结束，交易流水号：" + commonMsg.getHead().getTransSeqNo()+ ",path="+ this.getClass()); 
		return rep;
	}

	/**
	 * 发送邮件（习题资料）
	 */
	@ApiOperation(value="发送邮件（习题资料）", notes="发送邮件（习题资料）")
	@RequestMapping(value = "/unlockFileToSendEmail", method = RequestMethod.POST)
	public String unlockFileToSendEmail(@RequestBody CommonMsg<FileDataRequest,FileDataRequest> commonMsg) {
		GenTransSeqNo.SetTransSeqNo(commonMsg);
		logger.info(">>开始发送邮件（习题资料）接口unlockFileToSendEmail，交易流水号：" + commonMsg.getHead().getTransSeqNo() + "，path=" + this.getClass()); 
		logger.debug(">>传入参数head："
				+ ReflectionToStringBuilder.toString(commonMsg.getHead(), ToStringStyle.MULTI_LINE_STYLE));
		logger.debug(">>传入参数body：" + ReflectionToStringBuilder.toString(commonMsg.getBody(),
				ToStringStyle.MULTI_LINE_STYLE));
		SetChainPathUtils.setChainPathInfo(commonMsg, this.getClass().getPackage().getName()); 
		String result = sendEmailService.unlockFileToSendEmail(javaMailSender, commonMsg); 
		logger.info(">>交易结束，交易流水号：" + commonMsg.getHead().getTransSeqNo()+ ",path="+ this.getClass()); 
		return result;
	}
	
	/**
	 * 预览（习题资料）
	 */
	@ApiOperation(value="预览（习题资料）", notes="预览（习题资料）")
	@RequestMapping(value = "/unlockFileToPreview", method = RequestMethod.GET)
	public byte[] unlockFileToPreview(@RequestParam String fileDataNo, HttpServletResponse response) {
		response.setContentType("application/pdf");
 		byte[] rep = null;
 		logger.info(">>开始执行预览（习题资料），交易流水号：fileDataNo =" + fileDataNo + "，path=" + this.getClass()); 
		try {
			rep = sendEmailService.unlockFileToPreview(fileDataNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rep;
	}
	//上传图片
	@RequestMapping("/uploadFile")
	public String uploadFile(@RequestParam(value = "file", required = false) MultipartFile file,@RequestParam String questionNo) {
		
 		String rep = "上传图片失败";
 		logger.info(">>上传图片.....id = "+ questionNo); 
 		try {
 			rep = cosSerevice.uploadFile(file,questionNo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info(">>图片上传完成："); 
		
		return rep;
	}
	//word to pdf
//		@RequestMapping(value = "/convertWordToPdf", method = RequestMethod.GET)
//		public String convertWordToPdf(@RequestParam String inFilePath, @RequestParam String outFilePath,@RequestParam String model,String collName) {
//	 		List rep = new ArrayList();
//	 		logger.info(">>开始转化资料.....inFilePath = "+ inFilePath+"; outFilePath = "+outFilePath+";collName = "+collName+"; model= "+ model); 
//	 		rep = convertWordToPdf.convertWordToPdf(inFilePath, outFilePath, collName,model);
//			logger.info(">>转化资料完成："); 
//			return rep.toString();
//		}
}
