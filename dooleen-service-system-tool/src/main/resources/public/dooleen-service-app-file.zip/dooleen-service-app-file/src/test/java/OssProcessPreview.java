import java.net.URL;
import java.util.Date;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.GeneratePresignedUrlRequest;
import com.aliyun.oss.model.GetObjectRequest;

public class OssProcessPreview{
	
	private static String accessKeyId = "LTAIfvY72ii4QoOH";
	private static String accessKeySecret = "3zpQUGvvHCkfMGG11De9brov4XRMI7";
	
    public static void main(String[] args) {
//        String ak = "";
//        String sk = "";
        String bucketName = "dooleen-hangzhou";
        String objectKey = "1.png";
        URL url = getUrl("imm/detectface", accessKeyId, accessKeySecret, bucketName, objectKey);
        System.out.println(url.toString());
//        bucketName = "imm-user-zzh";
//        objectKey = "a.xlsx";
//        url = getUrl("imm/previewdoc", accessKeyId , accessKeySecret ,bucketName, objectKey);
//        System.out.println(url.toString());
    }
    private static URL getUrl(String process, String ak, String sk, String bucketName, String objectKey) {
        OSSClient client = new OSSClient(ak, sk);
        client.setEndpoint("oss-cn-hangzhou.aliyuncs.com");
        GetObjectRequest getObjectRequest = new GetObjectRequest(bucketName, objectKey);
        getObjectRequest.setProcess(process);
        GeneratePresignedUrlRequest request = new GeneratePresignedUrlRequest(bucketName, objectKey);
        request.setProcess(process);
        request.setExpiration(new Date(new Date().getTime() + 3600 * 1000));
        return client.generatePresignedUrl(request);
    }
}