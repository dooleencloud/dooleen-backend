package com.dooleen.service.app.file.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URL;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.PutObjectResult;
import com.dooleen.service.app.file.entity.ExportDomain;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.itextpdf.tool.xml.html.CssAppliers;
import com.itextpdf.tool.xml.html.CssAppliersImpl;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.parser.XMLParser;
import com.itextpdf.tool.xml.pipeline.css.CSSResolver;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.AbstractImageProvider;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;

import freemarker.template.Configuration;
import freemarker.template.Template;
import sun.misc.BASE64Encoder;
/**
 * Copy Right Information : 独领 <br>
 * Project : 神口算 <br>
 * Description : <br>
 * Author :李秋宏  <br>
 * Maintainer:  <br>
 * Version :  <br>
 * Since :  <br>
 * Date :2019-04-21 <br>
 * Update:  <br>
 */
@Service
public class PdfExportOssService {

  public String getFilePath() throws Exception {
	// Endpoint以杭州为例，其它Region请按实际情况填写。
	  String endpoint = "oss-cn-qingdao.aliyuncs.com";
	 	// 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建RAM账号。
	  String accessKeyId = "LTAIfvY72ii4QoOH";
	  String accessKeySecret = "3zpQUGvvHCkfMGG11De9brov4XRMI7";
	  String bucketName = "dooleen";
	  String objectName = "test.pdf";

	  // 创建OSSClient实例。
	  OSSClient ossClient = new OSSClient(endpoint, accessKeyId, accessKeySecret);

	  // 设置URL过期时间为1小时。
	  Date expiration = new Date(new Date().getTime() + 3600 * 1000);
	  // 生成以GET方法访问的签名URL，访客可以直接通过浏览器访问相关内容。
	  URL url = ossClient.generatePresignedUrl(bucketName, objectName, expiration);

	  // 关闭OSSClient。
	  ossClient.shutdown();
	  return url.toString();
	 }
  public String putFileToOss() throws Exception {
	byte[] bytes = getPdfStream("test.html",buildParam());
 	FileOutputStream fos = new FileOutputStream("/Users/apple/Documents/code/pdf/html2pdf/test4.pdf");
 	return "";
 	/*
	// 	
	//	fos.write(bytes);
	//	fos.close();
    // Endpoint以青岛为例，其它Region请按实际情况填写。
 	String endpoint = "oss-cn-qingdao.aliyuncs.com";
 	// 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建RAM账号。
 	String accessKeyId = "LTAIfvY72ii4QoOH";
 	String accessKeySecret = "3zpQUGvvHCkfMGG11De9brov4XRMI7";

 	// 创建OSSClient实例。
 	OSSClient ossClient = new OSSClient(endpoint, accessKeyId,accessKeySecret);

 	// 上传Byte数组。
 	byte[] content = "Hello OSS".getBytes();
 	PutObjectResult ps = ossClient.putObject("dooleen", "test.pdf", new ByteArrayInputStream(bytes));
    System.out.println(">>>>sdfsfd= " + ps.getETag());
 	// 关闭OSSClient。
 	ossClient.shutdown();
 	return "";
 	
 	*/
 }

  public static byte[] getPdfStream(String templateName, Map<String,Object> data)throws Exception{
     
	  String html= getHtmlContract(templateName,data);
	  //转换成pdf流
	  byte[] bytes = convertToPDF(html);
	  return bytes ;
 }

 /**
  * @description PDF文件生成
  */
 private  static byte[] convertToPDF(String htmlString)throws Exception{
	 ByteArrayOutputStream  out =  new ByteArrayOutputStream();
     //设置文档大小
     Document document = new Document(PageSize.A4);
     PdfWriter writer = PdfWriter.getInstance(document, out);
     //itext图片立即合成
     writer.setStrictImageSequence(true);
     
     //输出为PDF文件
     document.open();
     MyFontsProvider fontProvider = new MyFontsProvider();
     fontProvider.addFontSubstitute("lowagie", "garamond");
     fontProvider.setUseUnicode(true);
     CssAppliers cssAppliers = new CssAppliersImpl(fontProvider);
   
     CSSResolver cssResolver = XMLWorkerHelper.getInstance().getDefaultCssResolver(true);

     // HTML
     HtmlPipelineContext htmlContext = new HtmlPipelineContext(cssAppliers);
     htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());
     htmlContext.setImageProvider(new AbstractImageProvider() {
         @Override
         public Image retrieve(String src) {
             int pos = src.indexOf("base64,");
             try {
                 if (src.startsWith("data") && pos > 0) {
                     byte[] img = Base64.decode(src.substring(pos + 7));
                     return Image.getInstance(img);
                 } else if (src.startsWith("http")) {
                     return Image.getInstance(src);
                 } 
             } catch (BadElementException ex) {
                 return null;
             } catch (IOException ex) {
                 return null;
             }
             return null;
         }
         @Override
         public String getImageRootPath() {
             return null;
         }
     });

     // Pipelines
     PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
     HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
     CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

     // XML Worker
     XMLWorker worker = new XMLWorker(css, true);
     XMLParser p = new XMLParser(worker);
     p.parse(new StringReader(htmlString));
     document.close();
     return out.toByteArray();
 }
 public static String getHtmlContract(String html, Map<String, Object> dataModel) throws Exception {
		Writer out = null;
		StringReader reader = null;
		try {
			out = new StringWriter();
			Configuration cfg = new Configuration();
			cfg.setDefaultEncoding("UTF-8");
			Resource resource = new ClassPathResource("templates");
			cfg.setDirectoryForTemplateLoading(resource.getFile());
			// cfg.setDirectoryForTemplateLoading(new File("./templates"));

			Template template = cfg.getTemplate(html);
			template.process(dataModel, out);
			reader = new StringReader(out.toString());
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (out != null) {
				out.close();
			}
		}
		BufferedReader br = new BufferedReader(reader);
		StringBuilder content = new StringBuilder();
		String str = null;
		while ((str = br.readLine()) != null) {
			content.append(str);
		}
		return content.toString();
	
}
 public static Map<String, Object> buildParam() throws Exception {
	 
	 List<ExportDomain> list = new ArrayList<ExportDomain>();
     ExportDomain exportDomain = new ExportDomain();
//     exportDomain.setUserName("张三");
//     exportDomain.setRoleName("管理员");
//     exportDomain.setMenuName("功能1");
//     list.add(exportDomain);
//     ExportDomain exportDomain1 = new ExportDomain();
//     exportDomain1.setUserName("李四");
//     exportDomain1.setRoleName("办理员");
//     exportDomain1.setMenuName("功能2");
//     list.add(exportDomain1);
//     ExportDomain exportDomain2 = new ExportDomain();
//     exportDomain2.setUserName("王五");
//     exportDomain2.setRoleName("稽核员");
//     exportDomain2.setMenuName("功能3");
    // list.add(exportDomain2);

     Map<String, Object> dataModel = new HashMap<String, Object>();
     dataModel.put("title", "HTML转PDF测试");
     dataModel.put("userList", list);
     dataModel.put("reportDate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
     dataModel.put("reportUser", "大哥大");
     
     File file = new File("/Users/apple/Documents/code/pdf/html2pdf/bskji.png");
     byte[] fileByte = Files.readAllBytes(file.toPath());
	 String s = new BASE64Encoder().encode(fileByte);
	 String img =  "data:image/jpg;base64," + s;
     dataModel.put("pic", img);
     return dataModel ;
 	}

 }





