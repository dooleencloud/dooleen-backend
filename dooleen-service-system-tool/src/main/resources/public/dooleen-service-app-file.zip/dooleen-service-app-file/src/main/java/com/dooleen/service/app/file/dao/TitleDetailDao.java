package com.dooleen.service.app.file.dao;

import com.dooleen.common.core.entity.TitleDetail;
import com.dooleen.common.core.tkMapper.TkMapper;
/**
 * @Copy Right Information : 独领科技版权所有
 * @Project : 独领教育平台
 * @Project No : dooleen
 * @Version : 1.0.0
 * @CreateDate : 2019-07-23 9:00:00 +++++++++++++maintainer1 info+++++++++++++
 * @Description :
 * @Maintainer:zoujin
 * @Update:
 */
public interface TitleDetailDao extends TkMapper<TitleDetail> {

}
