#!/bin/sh
PID=$(cat /root/dooleen/data/dooleen-service-app-file.pid)
kill -9 $PID