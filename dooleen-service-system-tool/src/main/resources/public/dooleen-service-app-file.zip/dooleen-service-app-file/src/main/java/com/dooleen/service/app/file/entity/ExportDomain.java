package com.dooleen.service.app.file.entity;

import java.util.List;

import com.dooleen.common.core.entity.TitleDetail;

public class ExportDomain {
	
	private int lineNum;
    private String typeNum;
    private String ruleNo;
    private String ruleName;
    private List<TitleDetail> titleDetailList;
    
	public int getLineNum() {
		return lineNum;
	}
	public void setLineNum(int lineNum) {
		this.lineNum = lineNum;
	}
	
	public String getTypeNum() {
		return typeNum;
	}
	public void setTypeNum(String typeNum) {
		this.typeNum = typeNum;
	}
	public String getRuleNo() {
		return ruleNo;
	}
	public void setRuleNo(String ruleNo) {
		this.ruleNo = ruleNo;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	public List<TitleDetail> getTitleDetailList() {
		return titleDetailList;
	}
	public void setTitleDetailList(List<TitleDetail> titleDetailList) {
		this.titleDetailList = titleDetailList;
	}
   

}
