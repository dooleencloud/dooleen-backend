package com.dooleen.service.app.file.service;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dooleen.common.core.entity.QuestionSheet;
import com.dooleen.common.core.utils.AliyunUtils;
import com.dooleen.common.core.utils.GenerateNo;
import com.dooleen.service.app.file.dao.QuestionSheetDao;
import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.model.ObjectMetadata;
import com.qcloud.cos.region.Region;

@Service
public class CosSerevice {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private GenerateNo genNo;
	private String secretId = "AKIDJRK4aqmDE0Wmogsl26uTnrhIhxxi7TVJ";
	private String secretKey = "iEZfV5QVO2UjkV3LODnBNL3VifQwGOIw";
	
	@Autowired
	private AliyunUtils aliyunUtils;
	
	@Autowired
	private QuestionSheetDao questionSheetDao;

	/**
	 * @throws IOException 
	* @Title: uploadFile  (调用阿里的二维码检测)
	* @Description: TODO(这里用一句话描述这个方法的作用)  
	* @param @param file
	* @param @param questionNo
	* @param @return
	* @param @throws Exception    参数  
	* @return String    返回类型  
	* @throws
	 */
	public String uploadFile(MultipartFile file, String questionNo) throws IOException {
		
		InputStream fileInputStream = file.getInputStream();
		String fileOrgName = file.getOriginalFilename();
//		String fileName = questionNo + "." + fileOrgName.substring(fileOrgName.lastIndexOf(".") + 1);
		String fileName = questionNo + ".png";
		//查询题单信息
		QuestionSheet questionSheet = questionSheetDao.selectByPrimaryKey(questionNo);
		//资料编号
		String fileDataNo = questionSheet.getFileDataNo();
		
		//上传图片
		String uploadResult = aliyunUtils.uploadFile(fileInputStream, fileName);
		logger.info("uploadResult: {}", uploadResult);
		
		//检测二维码
		String detectResult = "";
		try {
			detectResult = aliyunUtils.DetectQRCodes(fileName);
			logger.info("detectResult: {}", detectResult);			
		} catch (Exception e) {
			//删除图片
			String deleteResult = aliyunUtils.deleteFile(fileName);
			logger.info("catch-deleteResult: {}", deleteResult);
			fileName = "error-上传试卷图片非该题单所打印！";
			return fileName;
		}
		
		//删除上传图片标志
		boolean deleteFlag = false;
		if("2".equals(questionSheet.getQuestionSource())) {
			//如果题单存的文件编号跟上传的文件编号不相等，则删除对应的上传文件
			if(!fileDataNo.equals(detectResult)) {
				deleteFlag = true;
			}
		}else {			
			//如果不是题单对应的照片，则删除; 
			if(!questionNo.equals(detectResult)) {
				deleteFlag = true;
			}
		}
		
		if(deleteFlag) {
			//删除图片
			String deleteResult = aliyunUtils.deleteFile(fileName);
			logger.info("deleteResult: {}", detectResult);
			fileName = "error-上传试卷图片非该题单所打印！";
			return fileName;
		}
		
		return "success";
//		// 1 初始化用户身份信息（secretId, secretKey）。
//		COSCredentials cred = new BasicCOSCredentials(secretId, secretKey);
//		// 2 设置 bucket 的区域, COS 地域的简称请参照
//		// https://cloud.tencent.com/document/product/436/6224
//		// clientConfig 中包含了设置 region, https(默认 http), 超时, 代理等 set 方法, 使用可参见源码或者常见问题
//		// Java SDK 部分。
//		Region region = new Region("ap-chengdu");
//		ClientConfig clientConfig = new ClientConfig(region);
//		// 3 生成 cos 客户端。
//		COSClient cosClient = new COSClient(cred, clientConfig);
//		// 方法1 将本地文件上传到 COS
//		String bucketName = "mymirror-1259592194";
//		String fileOrgName = file.getOriginalFilename();
//		String fileName = "examFile/" + questionNo + "." + fileOrgName.substring(fileOrgName.lastIndexOf(".") + 1);
//		System.out.println("sufiff = "+fileOrgName.substring(fileOrgName.lastIndexOf(".") + 1));
//		// 获取文件流
//		byte[] bytes = file.getBytes();
//
//		int length = bytes.length;
//		String text = GetCommonQRcode.decodeQR(bytes);
//		System.out.println(text);
//		if (questionNo != null && questionNo.equals(text.trim())) {
//			InputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
//			ObjectMetadata objectMetadata = new ObjectMetadata();
//			// 从输入流上传必须制定content length, 否则http客户端可能会缓存所有数据，存在内存OOM的情况
//			objectMetadata.setContentLength(length);
//			// 默认下载时根据cos路径key的后缀返回响应的contenttype, 上传时设置contenttype会覆盖默认值
//			// objectMetadata.setContentType("image/jpeg");
//			cosClient.putObject(bucketName, fileName, byteArrayInputStream, objectMetadata).getRequestId();
//		}
//		else {
//			fileName = "error-上传试卷图片非该题单所打印！";
//		}
//		return fileName;
	}
}
